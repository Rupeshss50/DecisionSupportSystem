	import java.applet.* ;
	import java.awt.*;
/*
<applet code="BarChart" height=300 width=400>   </applet> */
        
public class BarChart extends Applet
{
    

       TextField t1,t2,t3;
       public void init(){
             t1 = new TextField(8);
             t2 = new TextField(8);
             t3 = new TextField(8);
             add(t1);
             add(t2);
             add(t3);
             t1.setText("0");
             t2.setText("0");
             t3.setText("0");
        }

        public void paint(Graphics g){
             try{
                     g.drawString("Enter value in TextField to generate Barchart ",10,50);
                     int value[] = new int[2];
                     g.setColor(Color.red);
              value[0]= Integer.parseInt(t1.getText());
              value[1]=Integer.parseInt(t2.getText());
              value[2]=Integer.parseInt(t3.getText());

             for (int i=0;i<3;i++ )
             {
                    g.fillRect(100,i*50+70,value[i],40);
            }
            }catch(Exception e) {}
         }


          public boolean action(Event e, Object o){
          repaint();
          return true;
        }
    





}
