 import java.awt.EventQueue;
 import javax.swing.JFrame;
  public class Main implements Runnable
  {
    public void run()
      {
    //    frame.setVisible(true);
      }
  
      public static void main(String[] args) {
       
       java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() 
            {
                new Login().setVisible(true);

            }
         });          
          
    }
  }  
    
 