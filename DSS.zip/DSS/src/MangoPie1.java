import java.awt.*;
import java.applet.Applet;
import javax.swing.JApplet;
import java.awt.Color;
import java.io.*;
import java.util.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageProducer;
import java.sql.Array;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MangoPie1 extends javax.swing.JFrame {
    public Connection conn;
  
    
    public MangoPie1() 
    {
        initComponents();
    }
    
    
    public void paint(Graphics g)
    {
        int Mango1, Mango2, Mango3, Total;
        int Temp1, Temp2, Temp3, Total_Temp; 
        float PercMango1, PercMango2, PercMango3;
        float PercMango4,PercMango5,PercMango6;
	float PercTemp1 , PercTemp2 , PercTemp3;
	float PercTemp4 ,PercTemp5, PercTemp6; 	
         // the coordinates and size of the pie is fixed below
		int x = 100, y = 150, w = 200, h = 200;
		
		int x1 = 400, y1 = 100 , w1 = 300 , h1 = 300;
                    // these quantities will need to be computed for each slice
		int startAngle = 0, degrees;		
	        int startAngle1 = 0, degrees1;
         
                try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
             
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_100");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }

           	
                Mango1 = Quantities1[0];
		Mango2 = Quantities1[1];
		Mango3 = Quantities1[2];
		
		Temp1 = Temp[0];
		Temp2 = Temp[1];
		Temp3 = Temp[2];
		


                // Computer percentages
		Total = Mango1 + Mango2 + Mango3;
		Total_Temp = Temp1 + Temp2 + Temp3;
                
		PercMango1 = Mango1 * 100.0f / Total;
		PercMango2 = Mango2 * 100.0f / Total;
		PercMango3 = Mango3 * 100.0f / Total;
	
	        
                
                PercTemp1 = Temp1 * 100.0f / Total_Temp;
		PercTemp2 = Temp2 * 100.0f / Total_Temp;
		PercTemp3 = Temp3 * 100.0f / Total_Temp;
	                

// Print out results for checking
                Font f=new Font("TimesRoman",Font.BOLD,20);
                
                g.setFont(f);
		g.setColor(Color.black);
                g.drawString("Total-Mango:"+Total,100,80);

                g.setColor(Color.red);
		g.drawString(""+Mango1,300,180);
                g.drawString("ALPHONSO:"+Mango1,150,450);
       
                g.setColor(Color.green);
                g.drawString(""+Mango2,80,200);
                g.drawString("TOTAPURI:"+Mango2,150,500);
	
                g.setColor(Color.blue);
                g.drawString(""+Mango3,200,380);
                g.drawString("DASHERI:"+Mango3,150,550);
               
                g.setFont(f);
                g.setColor(Color.black);
                g.drawString("Total-Temperature:"+Total_Temp,500,80);
	        
                g.setColor(Color.red);
                g.drawString(""+Temp1,700,180);
		g.drawString("ALPHONSO-Temp:"+Temp1,450,450);
               
                g.setColor(Color.green);
                g.drawString(""+Temp2,370,180);
		g.drawString("TOTAPURI-Temp:"+Temp2,450,500);
                
                g.setColor(Color.blue);
                g.drawString(""+Temp3,700,380);
		g.drawString("DASHERI-Temp:"+Temp3,450,550);		
// Display the Pie Chart
		// Display the Pie for Mango1
		degrees = (int) (PercMango1*360/100);
                g.setColor(Color.red);
	
                g.fillArc(x, y, w, h, startAngle, degrees);
                
	
                degrees1 = (int) (PercTemp1*360/100);
		g.setColor(Color.red);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
                               
		// Pie for Mango2
		
                startAngle = degrees;
		degrees = (int) (PercMango2*360/100);
		g.setColor(Color.green);
                g.fillArc(x, y, w, h, startAngle, degrees);
	
                
		startAngle1=degrees1;
                degrees1 = (int) (PercTemp2*360/100);
		g.setColor(Color.green);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
                

              // Pie for Mango3
		
           
                startAngle = startAngle + degrees;
		degrees = (int) (PercMango3*360/100);
		g.setColor(Color.blue);
                g.fillArc(x, y, w, h, startAngle, degrees);
                
                
                startAngle1 = startAngle1 + degrees1;
                degrees1 = (int) (PercTemp3*360/100);
		g.setColor(Color.blue);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
                
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Fruit_100");
        setAlwaysOnTop(true);
        setFocusCycleRoot(false);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(302, 302, 302)
                .addComponent(jLabel3)
                .addContainerGap(527, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel3)
                .addContainerGap(536, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MangoPie1().setVisible(true);
            }
        });    
       
    }     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
