
import java.awt.*;
import java.applet.Applet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JApplet;


public class PearsPie1 extends javax.swing.JFrame {

    public PearsPie1() {
        initComponents();
    }

 public void paint(Graphics g)
    {
     	
               int Pears1, Pears2, Pears3, Total;
               int Temp1, Temp2, Temp3, Total_Temp;
               float PercPears1, PercPears2, PercPears3;
               float PercTemp1 , PercTemp2 , PercTemp3;
		
		
		// Set # of students in each discipline
		int x = 100, y = 150, w = 200, h = 200;
		int x1 = 400, y1 = 100 , w1 = 300 , h1 = 300;
		// these quantities will need to be computed for each slice
		int startAngle = 0, degrees;
		int startAngle1 = 0, degrees1;
		
                
                try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
            
             
               try
               {
             
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_106");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
               
                     while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_Temp");  
                            Quantities1[i]=rs.getInt("F_Quantity");                             
                             rs.next();
                        }
                      
                    }
            
               
                  }
               
               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
                               
                
		
               Pears1 = Quantities1[0];
	       Pears2 = Quantities1[1];
	       Pears3 = Quantities1[2];
		
                Temp1 = Temp[0];
		Temp2 = Temp[1];
		Temp3 = Temp[2];
		
           
                
		
		
		// Computer percentages
		Total =Pears1 +Pears2 +Pears3;
		Total_Temp = Temp1 + Temp2 + Temp3;

          
		
		PercPears1 = Pears1 * 100.0f / Total;
		PercPears2 = Pears2 * 100.0f / Total;
		PercPears3 = Pears3 * 100.0f / Total;
	
                PercTemp1 = Temp1 * 100.0f / Total_Temp;
		PercTemp2 = Temp2 * 100.0f / Total_Temp;
		PercTemp3 = Temp3 * 100.0f / Total_Temp;
                
                
                              
		// Print out results for checking

                Font f=new Font("TimesRoman",Font.BOLD,20);
                g.setFont(f);
		g.setColor(Color.black);
                g.drawString("Total-Pears:"+Total,100,80);
		
                g.setColor(Color.red);
		g.drawString(""+Pears1,300,180);                      
		g.drawString("ANJOU:"+Pears1,150,450);
                
                g.setColor(Color.green);
                g.drawString(""+Pears2,80,200);             
                g.drawString("BARTLET:"+Pears2,150,500);
		
                g.setColor(Color.blue);
                g.drawString(""+Pears3,200,380);          
                g.drawString("BOSC:"+Pears3,150,550);
               
                g.setFont(f);
                g.setColor(Color.black);                
                g.drawString("Temperature-Total:"+Total_Temp,500,80);
		
		g.setColor(Color.red);
                g.drawString(""+Temp1,700,180);                       
	        g.drawString("ANJOU-Temp:"+Temp1,400,450);
                
		g.setColor(Color.green);
                g.drawString(""+Temp2,370,180);
                g.drawString("BARTLETT-Temp:"+Temp2,400,500);
                
		
                g.setColor(Color.blue);
                g.drawString(""+Temp3,700,380);                          
                g.drawString("BOSC-Temp:"+Temp3,400,550);			
	        
                     
		// Display the Pie Chart
		// Display the Pie for Pears1ences
		degrees = (int) (PercPears1*360/100);
		g.setColor(Color.red);
		g.fillArc(x, y, w, h, startAngle, degrees);
                
                
                degrees1 = (int) (PercTemp1*360/100);
		g.setColor(Color.red);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
		
                
		
		// Pie for Pears2
		startAngle = degrees;
		degrees = (int) (PercPears2*360/100);
                g.setColor(Color.green);
		g.fillArc(x, y, w, h, startAngle, degrees);
	
                
	
                
                startAngle1=degrees1;
                degrees1 = (int) (PercTemp2*360/100);
                g.setColor(Color.green);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
                    



// Pie for Pears3
		startAngle = startAngle + degrees;
		degrees = (int) (PercPears3*360/100);
		g.setColor(Color.blue);
		g.fillArc(x, y, w, h, startAngle, degrees);
                
                startAngle1 = startAngle1 + degrees1;
                degrees1 = (int) (PercTemp3*360/100);
		g.setColor(Color.blue);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
    
                     
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Fruit_106");
        setAlwaysOnTop(true);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 926, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 636, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PearsPie1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
