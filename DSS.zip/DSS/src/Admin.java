
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Admin extends javax.swing.JFrame {
    private Connection conn;

    public Admin() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("jMenu5");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Admin");
        setResizable(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setText("         WELCOME TO DSS FOOD PROCESSING SYSTEM");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 16)); // NOI18N
        jLabel2.setText("USER:ADMIN");

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("Logout");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel6.setText("Product-Table:");

        jButton5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton5.setText("View");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        jTable1.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "      P_id", "     P_name", "     P_price", "    P_Location"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setCellSelectionEnabled(true);
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTable1.setRowHeight(30);
        jTable1.setRowMargin(10);
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);
        jTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jLabel5.setText("Status");

        jButton6.setText("View");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton4.setText("Check");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 20)); // NOI18N
        jLabel3.setText("Temperature");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setText("Stock");

        jButton7.setText("View");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(38, 38, 38)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE))))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel8.setText("   FRUIT:");

        jComboBox1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "100", "101", "102", "103", "104", "105", "106" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTextArea1.setBackground(new java.awt.Color(0, 204, 255));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton2.setText("SEND");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("CLEAR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel7.setText("DECISION:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel6)
                                .addGap(31, 31, 31)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jLabel8)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(30, 30, 30)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(35, 35, 35)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(129, 129, 129))
                            .addComponent(jScrollPane1))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable()
                          {
                              public void run()
                            {
                               new Login().setVisible(true);
                            }
                          });
                      this.dispose();                 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         String Product_id, product_name, product_quantities, product_prize,product_location,order_date,expiry_date;
    Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
        } 
        catch (SQLException ex) {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }
               PreparedStatement ps1;
        try {
                         ps1 = conn.prepareStatement(" SELECT * FROM Product ");
                         ps1.executeQuery();     
                         ResultSet rs = ps1.executeQuery();
                         int Numrow = 0;
                         while(rs.next())
                      {
                       jTable1.setValueAt(rs.getString(1), Numrow, 0);
                       jTable1.setValueAt(rs.getString(2), Numrow, 1);
                       jTable1.setValueAt(rs.getString(3), Numrow, 2);
                       jTable1.setValueAt(rs.getString(4), Numrow, 3);
                       Numrow++;                                                  
                     }
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
        }
               
                                         
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
           
        
        String food_id1= (String) jComboBox1.getSelectedItem();
       
         if(food_id1.contentEquals("100"))
          {
              java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MangoPie1().setVisible(true);
            }
        });

          }
        
          if(food_id1.contentEquals("101"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ApplePie1().setVisible(true);
            }
        });

          }
          
           if(food_id1.contentEquals("102"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StrawberriesPie1().setVisible(true);
            }
        });

          }
           
            if(food_id1.contentEquals("103"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BananaPie1().setVisible(true);
            }
        });

          }
            
             if(food_id1.contentEquals("104"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BlackberriesPie1().setVisible(true);
            }
        });

          }
          
             if(food_id1.contentEquals("105"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GrapesPie1().setVisible(true);
            }
        });

          }
              if(food_id1.contentEquals("106"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PearsPie1().setVisible(true);
            }
        });

          }         
                                            
    
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    String msg=jTextArea1.getText();  
    String fruit_id= (String) jComboBox1.getSelectedItem();    
      try
        {
           Class.forName("oracle.jdbc.driver.OracleDriver");
        }
        catch(ClassNotFoundException e)
          {
            System.exit(-1);
           }
   
             if ((msg.isEmpty()))
             {
                  JOptionPane.showMessageDialog(null, "Please Enter the  Message:", "Message Sending" ,JOptionPane.ERROR_MESSAGE);
             }
            else
            {
                 try
                {
                  Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
                   PreparedStatement ps = conn.prepareStatement("insert into Admin100 values (?,?)");
                     ps.setString (1,fruit_id);
                     ps.setString (2,msg);
                     ps.execute();
                     System.out.println("Messeage is successfully send...");
                     JOptionPane.showMessageDialog(null, "Message is Succesfully Send:", "Message Send" ,JOptionPane.INFORMATION_MESSAGE);
                     jTextArea1.setText("");
                   }                              //end of the try statementt
             
                  catch (java.sql.SQLException e)
                 {
                    JOptionPane.showMessageDialog(null, "Error on message sending operation:", "Database Error", JOptionPane.ERROR_MESSAGE);
                    System.exit(-1);
                  }

            }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
          jTextArea1.setText("");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
     String food_id1= (String) jComboBox1.getSelectedItem();
     if(food_id1.contentEquals("100"))
     {
      jTextArea1.setText("\t Mango");   
     }
     if(food_id1.contentEquals("101"))
     {
      jTextArea1.setText("\t Apple");   
     }
     if(food_id1.contentEquals("102"))
     {
      jTextArea1.setText("\t Strawberries");   
     }
     if(food_id1.contentEquals("103"))
     {
      jTextArea1.setText("\t Banana");   
     }
     if(food_id1.contentEquals("104"))
     {
      jTextArea1.setText("\t Blackberries");   
     }
     if(food_id1.contentEquals("105"))
     {
      jTextArea1.setText("\t Grapes");   
     }
     if(food_id1.contentEquals("106"))
     {
      jTextArea1.setText("\t Pears");   
     }   
              
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
    
       String food_id1= (String) jComboBox1.getSelectedItem();
       
         if(food_id1.contentEquals("100"))
          {
              java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MangoStock().setVisible(true);
            }
        });

          }
        
          if(food_id1.contentEquals("101"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AppleStock().setVisible(true);
            }
        });

          }
          
           if(food_id1.contentEquals("102"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StrawberriesStock().setVisible(true);
            }
        });

          }
           
            if(food_id1.contentEquals("103"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BananaStock().setVisible(true);
            }
        });

          }
            
             if(food_id1.contentEquals("104"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BlackberriesStock().setVisible(true);
            }
        });

          }
          
             if(food_id1.contentEquals("105"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GrapesStock().setVisible(true);
            }
        });

          }
              if(food_id1.contentEquals("106"))
          {
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PearsStock().setVisible(true);
            }
        });

          }         
        
              
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyPressed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       
    String food_id2= (String) jComboBox1.getSelectedItem();
       
         if(food_id2.contentEquals("100"))
          {          
            jTextArea1.append("\n 1.Alphonso");   
            jTextArea1.append("\n 2.Totapuri");
            jTextArea1.append("\n 3.Dasheri");
              
             try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_100");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
               
                   int Mango1 = Quantities1[0];
                   int Mango2 = Quantities1[1];
                   int Mango3 = Quantities1[2];
                   int Temp1 = Temp[0];
                   int Temp2 = Temp[1];
                   int Temp3 = Temp[2];
		
                 if( Temp1>=30 && Temp1<=35)
                 {    
                      jTextArea1.append("\n1. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp1<30) 
                 {
                     jTextArea1.append("\n1. Low Temperature:(<30)");    
                 }
            
                 if(Temp1>35) 
                 {
                     jTextArea1.append("\n1.High Temperature:(>35)");
                 }
                 if( Temp2>=30 && Temp2<=35)
                 {    
                      jTextArea1.append("\n2. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp2<30) 
                 {
                     jTextArea1.append("\n2. Low Temperature:(<30)");    
                 }
            
                 if(Temp2>35) 
                 {
                     jTextArea1.append("\n2.High Temperature:(>35)");
                 }       
                 
                 if( Temp3>=30 && Temp3<=35)
                 {    
                      jTextArea1.append("\n3. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp3<30) 
                 {
                     jTextArea1.append("\n3. Low Temperature:(<30)");    
                 }
            
                 if(Temp3>35) 
                 {
                     jTextArea1.append("\n3.High Temperature :(>35)");
                 }         
                 
          
          
      
          }   
        
         if(food_id2.contentEquals("101"))
          {          
            jTextArea1.append("\n 1.Simla");   
            jTextArea1.append("\n 2.Dewgan");
            jTextArea1.append("\n 3.Fuzi");
              
             try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_101");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
               
                   int Mango1 = Quantities1[0];
                   int Mango2 = Quantities1[1];
                   int Mango3 = Quantities1[2];
                   int Temp1 = Temp[0];
                   int Temp2 = Temp[1];
                   int Temp3 = Temp[2];
		
                 if( Temp1>=30 && Temp1<=35)
                 {    
                      jTextArea1.append("\n1. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp1<30) 
                 {
                     jTextArea1.append("\n1. Low Temperature:(<30)");    
                 }
            
                 if(Temp1>35) 
                 {
                     jTextArea1.append("\n1.High Temperature:(>35)");
                 }
                 if( Temp2>=30 && Temp2<=35)
                 {    
                      jTextArea1.append("\n2. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp2<30) 
                 {
                     jTextArea1.append("\n2. Low Temperature:(<30)");    
                 }
            
                 if(Temp2>35) 
                 {
                     jTextArea1.append("\n2.High Temperature:(>35)");
                 }       
                 
                 if( Temp3>=30 && Temp3<=35)
                 {    
                      jTextArea1.append("\n3. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp3<30) 
                 {
                     jTextArea1.append("\n3. Low Temperature:(<30)");    
                 }
            
                 if(Temp3>35) 
                 {
                     jTextArea1.append("\n3.High Temperature :(>35)");
                 }          
          }
         
         
         
         
         if(food_id2.contentEquals("102"))
          {          
            jTextArea1.append("\n 1.EverBearing");   
            jTextArea1.append("\n 2.Day-Neutral");
            jTextArea1.append("\n 3.June-Bearing");
              
             try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_102");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
               
                   int Mango1 = Quantities1[0];
                   int Mango2 = Quantities1[1];
                   int Mango3 = Quantities1[2];
                   int Temp1 = Temp[0];
                   int Temp2 = Temp[1];
                   int Temp3 = Temp[2];
		
                 if( Temp1>=30 && Temp1<=35)
                 {    
                      jTextArea1.append("\n1. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp1<30) 
                 {
                     jTextArea1.append("\n1. Low Temperature:(<30)");    
                 }
            
                 if(Temp1>35) 
                 {
                     jTextArea1.append("\n1.High Temperature:(>35)");
                 }
                 if( Temp2>=30 && Temp2<=35)
                 {    
                      jTextArea1.append("\n2. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp2<30) 
                 {
                     jTextArea1.append("\n2. Low Temperature:(<30)");    
                 }
            
                 if(Temp2>35) 
                 {
                     jTextArea1.append("\n2.High Temperature:(>35)");
                 }       
                 
                 if( Temp3>=30 && Temp3<=35)
                 {    
                      jTextArea1.append("\n3. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp3<30) 
                 {
                     jTextArea1.append("\n3. Low Temperature:(<30)");    
                 }
            
                 if(Temp3>35) 
                 {
                     jTextArea1.append("\n3.High Temperature :(>35)");
                 }          
          }
         
         if(food_id2.contentEquals("103"))
          {          
            jTextArea1.append("\n 1.Cavendish");   
            jTextArea1.append("\n 2.Mahanandi");
            jTextArea1.append("\n 3.Elaichi");
              
             try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_103");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
               
                   int Mango1 = Quantities1[0];
                   int Mango2 = Quantities1[1];
                   int Mango3 = Quantities1[2];
                   int Temp1 = Temp[0];
                   int Temp2 = Temp[1];
                   int Temp3 = Temp[2];
		
                 if( Temp1>=30 && Temp1<=35)
                 {    
                      jTextArea1.append("\n1. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp1<30) 
                 {
                     jTextArea1.append("\n1. Low Temperature:(<30)");    
                 }
            
                 if(Temp1>35) 
                 {
                     jTextArea1.append("\n1.High Temperature:(>35)");
                 }
                 if( Temp2>=30 && Temp2<=35)
                 {    
                      jTextArea1.append("\n2. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp2<30) 
                 {
                     jTextArea1.append("\n2. Low Temperature:(<30)");    
                 }
            
                 if(Temp2>35) 
                 {
                     jTextArea1.append("\n2.High Temperature:(>35)");
                 }       
                 
                 if( Temp3>=30 && Temp3<=35)
                 {    
                      jTextArea1.append("\n3. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp3<30) 
                 {
                     jTextArea1.append("\n3. Low Temperature:(<30)");    
                 }
            
                 if(Temp3>35) 
                 {
                     jTextArea1.append("\n3.High Temperature :(>35)");
                 }          
          }
         
         
         if(food_id2.contentEquals("104"))
          {          
            jTextArea1.append("\n 1.MullBeries:");   
            jTextArea1.append("\n 2.BlueBerries:");
            jTextArea1.append("\n 3.RassBeries:");
              
             try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_104");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
               
                   int Mango1 = Quantities1[0];
                   int Mango2 = Quantities1[1];
                   int Mango3 = Quantities1[2];
                   int Temp1 = Temp[0];
                   int Temp2 = Temp[1];
                   int Temp3 = Temp[2];
		
                 if( Temp1>=30 && Temp1<=35)
                 {    
                      jTextArea1.append("\n1. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp1<30) 
                 {
                     jTextArea1.append("\n1. Low Temperature:(<30)");    
                 }
            
                 if(Temp1>35) 
                 {
                     jTextArea1.append("\n1.High Temperature:(>35)");
                 }
                 if( Temp2>=30 && Temp2<=35)
                 {    
                      jTextArea1.append("\n2. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp2<30) 
                 {
                     jTextArea1.append("\n2. Low Temperature:(<30)");    
                 }
            
                 if(Temp2>35) 
                 {
                     jTextArea1.append("\n2.High Temperature:(>35)");
                 }       
                 
                 if( Temp3>=30 && Temp3<=35)
                 {    
                      jTextArea1.append("\n3. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp3<30) 
                 {
                     jTextArea1.append("\n3. Low Temperature:(<30)");    
                 }
            
                 if(Temp3>35) 
                 {
                     jTextArea1.append("\n3.High Temperature :(>35)");
                 }          
          }
         
         
         if(food_id2.contentEquals("105"))
          {          
            jTextArea1.append("\n 1.Champagne");   
            jTextArea1.append("\n 2.Concard");
            jTextArea1.append("\n 3.Cotton-Candy");
              
             try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_105");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
               
                   int Mango1 = Quantities1[0];
                   int Mango2 = Quantities1[1];
                   int Mango3 = Quantities1[2];
                   int Temp1 = Temp[0];
                   int Temp2 = Temp[1];
                   int Temp3 = Temp[2];
		
                 if( Temp1>=30 && Temp1<=35)
                 {    
                      jTextArea1.append("\n1. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp1<30) 
                 {
                     jTextArea1.append("\n1. Low Temperature:(<30)");    
                 }
            
                 if(Temp1>35) 
                 {
                     jTextArea1.append("\n1.High Temperature:(>35)");
                 }
                 if( Temp2>=30 && Temp2<=35)
                 {    
                      jTextArea1.append("\n2. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp2<30) 
                 {
                     jTextArea1.append("\n2. Low Temperature:(<30)");    
                 }
            
                 if(Temp2>35) 
                 {
                     jTextArea1.append("\n2.High Temperature:(>35)");
                 }       
                 
                 if( Temp3>=30 && Temp3<=35)
                 {    
                      jTextArea1.append("\n3. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp3<30) 
                 {
                     jTextArea1.append("\n3. Low Temperature:(<30)");    
                 }
            
                 if(Temp3>35) 
                 {
                     jTextArea1.append("\n3.High Temperature :(>35)");
                 }          
          }
         
         
         if(food_id2.contentEquals("106"))
          {          
            jTextArea1.append("\n 1.Anjou");   
            jTextArea1.append("\n 2.Bartlett");
            jTextArea1.append("\n 3.Bosc");
              
             try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
             
               try
               {
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_106");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
                                                    
                      while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_TEMP");  
                            Quantities1[i]=rs.getInt("F_QUANTITY");                             
                             rs.next();
                        }
                      
                    }
                       
               }

               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
               
                   int Mango1 = Quantities1[0];
                   int Mango2 = Quantities1[1];
                   int Mango3 = Quantities1[2];
                   int Temp1 = Temp[0];
                   int Temp2 = Temp[1];
                   int Temp3 = Temp[2];
		
                 if( Temp1>=30 && Temp1<=35)
                 {    
                      jTextArea1.append("\n1. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp1<30) 
                 {
                     jTextArea1.append("\n1. Low Temperature:(<30)");    
                 }
            
                 if(Temp1>35) 
                 {
                     jTextArea1.append("\n1.High Temperature:(>35)");
                 }
                 if( Temp2>=30 && Temp2<=35)
                 {    
                      jTextArea1.append("\n2. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp2<30) 
                 {
                     jTextArea1.append("\n2. Low Temperature:(<30)");    
                 }
            
                 if(Temp2>35) 
                 {
                     jTextArea1.append("\n2.High Temperature:(>35)");
                 }       
                 
                 if( Temp3>=30 && Temp3<=35)
                 {    
                      jTextArea1.append("\n3. Good Temperature Range:(30-35F)");     
                 }          
             
                 if(Temp3<30) 
                 {
                     jTextArea1.append("\n3. Low Temperature:(<30)");    
                 }
            
                 if(Temp3>35) 
                 {
                     jTextArea1.append("\n3.High Temperature :(>35)");
                 }          
          }
         
         
    }//GEN-LAST:event_jButton4ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
