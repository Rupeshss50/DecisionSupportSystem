import java.awt.*;
import java.applet.Applet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JApplet;

public class BlackberriesPie1 extends javax.swing.JFrame {

    public BlackberriesPie1() {
        initComponents();
    }

    public void paint(Graphics g)
    {

               int Blackberries1, Blackberries2, Blackberries3, Total;
               int Temp1, Temp2, Temp3, Total_Temp;
               float PercBlackberries1, PercBlackberries2, PercBlackberries3;
               float PercTemp1 , PercTemp2 , PercTemp3;
	
		// the coordinates and size of the pie is fixed below
		int x = 100, y = 150, w = 200, h = 200;
		int x1 = 400, y1 = 100 , w1 = 300 , h1 = 300;
		// these quantities will need to be computed for each slice
		int startAngle = 0, degrees;
		int startAngle1 = 0, degrees1;
		
                
                try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
            
             
               try
               {
             
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_104");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
               
                     while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_Temp");  
                            Quantities1[i]=rs.getInt("F_Quantity");                             
                             rs.next();
                        }
                      
                    }
            
               
                  }
               
               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
                               
                
		
               Blackberries1 = Quantities1[0];
	       Blackberries2 = Quantities1[1];
	       Blackberries3 = Quantities1[2];
		
                Temp1 = Temp[0];
		Temp2 = Temp[1];
		Temp3 = Temp[2];
		
           
                
		
		
		// Computer percentages
		Total =Blackberries1 +Blackberries2 +Blackberries3;
		Total_Temp = Temp1 + Temp2 + Temp3;

          
		
		PercBlackberries1 = Blackberries1 * 100.0f / Total;
		PercBlackberries2 = Blackberries2 * 100.0f / Total;
		PercBlackberries3 = Blackberries3 * 100.0f / Total;
	
                PercTemp1 = Temp1 * 100.0f / Total_Temp;
		PercTemp2 = Temp2 * 100.0f / Total_Temp;
		PercTemp3 = Temp3 * 100.0f / Total_Temp;
                
                
                              
		// Print out results for checking

                Font f=new Font("TimesRoman",Font.BOLD,20);
                g.setFont(f);
		g.setColor(Color.black);
                g.drawString("Total-Blackberries:"+Total,100,80);
		
		g.setColor(Color.red);
		g.drawString(""+Blackberries1,300,180);              
                g.drawString("MulBerries:"+Blackberries1,150,450);
                
                g.setColor(Color.green);
                g.drawString(""+Blackberries2,80,200);             
                g.drawString("BlueBerries::"+Blackberries2,150,500);
		
                g.setColor(Color.blue);
                g.drawString(""+Blackberries3,200,380);          
                g.drawString("RaasBerries:"+Blackberries3,150,550);
                
              
                g.setFont(f);
                g.setColor(Color.black);                
                g.drawString("Temperature-Total:"+Total_Temp,500,80);
		
		g.setColor(Color.red);
                g.drawString(""+Temp1,700,180);            
                g.drawString("MulBerries-Temp:"+Temp1,400,450);
               
		g.setColor(Color.green);
                g.drawString(""+Temp2,370,180);
                g.drawString("BlueBerries-Temp:"+Temp2,400,500);
                
		g.setColor(Color.blue);
                g.drawString(""+Temp3,700,380);                          
                g.drawString("RaasBerries-Temp:"+Temp3,400,550);			
	        
                
                          
		// Display the Pie Chart
		// Display the Pie for Blackberries1ences
		degrees = (int) (PercBlackberries1*360/100);
		g.setColor(Color.red);
		g.fillArc(x, y, w, h, startAngle, degrees);
                
                
                degrees1 = (int) (PercTemp1*360/100);
		g.setColor(Color.red);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
		
                
		
		// Pie for Blackberries2
		startAngle = degrees;
		degrees = (int) (PercBlackberries2*360/100);
                g.setColor(Color.green);
		g.fillArc(x, y, w, h, startAngle, degrees);
	
                
	
                
                startAngle1=degrees1;
                degrees1 = (int) (PercTemp2*360/100);
                g.setColor(Color.green);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
                    



// Pie for Blackberries3
		startAngle = startAngle + degrees;
		degrees = (int) (PercBlackberries3*360/100);
		g.setColor(Color.blue);
		g.fillArc(x, y, w, h, startAngle, degrees);
                
                startAngle1 = startAngle1 + degrees1;
                degrees1 = (int) (PercTemp3*360/100);
		g.setColor(Color.blue);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
    
    
    
    }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Fruit_104");
        setAlwaysOnTop(true);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 859, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 625, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BlackberriesPie1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BlackberriesPie1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BlackberriesPie1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BlackberriesPie1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BlackberriesPie1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
