import java.util.*;
public class BayesTherem
{
  public static void main(String args[])
 {
    Scanner sc=new Scanner(System.in);  
    int y=0;
	int n=0;
    System.out.println("\t Bayession Classification"); 
    String outlook[]={"sunny", "sunny", "ocast", "rain", "rain", "rain", "ocast", "sunny", "sunny", "rain", "sunny", "ocast", "ocast", "rain" };
    String Temprature[]={"hot","hot","hot","mild","cool","cool","cool","mild","cool","mild","mild","mild","hot","mild"};
    String Humidity[]={"high","high","high","high","normal","normal","normal","high","normal","normal","normal","high","normal","high"};
    String Wind[]={"false","true","false","false","false","true","true","false","false","false","true","true","false","true"};
    String Predict[]={"N","N","P","P","P","N","P","N","P","P","P","P","P","N"};
   
   for(int i=0;i<14;i++)
   {
     System.out.println(""+outlook[i]+"\t"+Temprature[i]+"\t"+Humidity[i]+"\t"+Wind[i]+"\t"+Predict[i]);  
   }	 
   
   for(int i=0;i<14;i++)
    {   
      if(Predict[i].equals("P"))
	  {
        y++;
      }
    else
	  {
	    n++;
	  }	
     }

     float p1=y;
	 float n1=n;
	 
	 p1=p1/14;
	 n1=n1/14;
	 
	 System.out.println("Probability of P:"+p1);
	 System.out.println("Probability of N:"+n1);
	 
    System.out.println("Enter the String:");
    System.out.println("Outlook:");
	String outlook1=sc.next();
	System.out.println("Temprature:");
	String Temprature1=sc.next();
	System.out.println("Humidity:");
	String Humidity1=sc.next();
	System.out.println("wind:");
	String wind1=sc.next();
	
    n=0;
    y=0;
	for(int i=0;i<14;i++)
	{
	  if(outlook[i].equals(outlook1))
     {	  
        if(Predict[i].equals("P"))
       {
            y++;
	    }
	else
	    {
            n++;
	    }		
     }
   }
   
     float p2=y;
	 float n2=n;
	 
	 p2=p2/9;
	 n2=n2/5;
	 
	 System.out.println("Probability of outlook(p):"+p2);
	 System.out.println("Probability of outlook(n):"+n2);


    n=0;
    y=0;
	for(int i=0;i<14;i++)
	{
	  if(Temprature[i].equals(Temprature1))
     {	  
        if(Predict[i].equals("P"))
       {
            y++;
	    }
	else
	    {
            n++;
	    }		
     }
   }
   
     float p3=y;
	 float n3=n;
	 
	 p3=p3/9;
	 n3=n3/5;
	 
	 System.out.println("Probability of Temprature(p):"+p3);
	 System.out.println("Probability of Temprature(n):"+n3);

    
    n=0;
    y=0;
	for(int i=0;i<14;i++)
	{
	  if(Humidity[i].equals(Humidity1))
     {	  
        if(Predict[i].equals("P"))
       {
            y++;
	    }
	else
	    {
            n++;
	    }		
     }
   }
   
     float p4=y;
	 float n4=n;
	 
	 p4=p4/9;
	 n4=n4/5;
	 
	 System.out.println("Probability of Humidity(p):"+p4);
	 System.out.println("Probability of Humidity(n):"+n4);

   
    n=0;
    y=0;
	for(int i=0;i<14;i++)
	{
	  if(Wind[i].equals(wind1))
     {	  
        if(Predict[i].equals("P"))
       {
            y++;
	    }
	else
	    {
            n++;
	    }		
     }
   }
   
     float p5=y;
	 float n5=n;
	 
	 p5=p5/9;
	 n5=n5/5;
	 
	 System.out.println("Probability of wind(p):"+p5);
	 System.out.println("Probability of wind(n):"+n5);
 
 
    System.out.println("Final Prediction value");
	
    float yes=((p1)*(p2)*(p3)*(p4)*(p5));
    float no=((n1)*(n2)*(n3)*(n4)*(n5));	
 
     System.out.println("Probability value of  P(yes):"+yes);
	 System.out.println("Probability value of  N(No):"+no);
 
     if(yes>no)
	 {
       System.out.println("yes");
	 }
 else 
     {
      System.out.println("no");
	 } 

 }
}