import java.awt.*;
import java.applet.Applet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JApplet;

public class BananaPie1 extends javax.swing.JFrame {

    public BananaPie1() {
        initComponents();
    }

     public void paint(Graphics g)
    {
               int Banana1, Banana2, Banana3, Total;
               int Temp1, Temp2, Temp3, Total_Temp;
               float PercBanana1, PercBanana2, PercBanana3;
               float PercTemp1 , PercTemp2 , PercTemp3;
	
		// the coordinates and size of the pie is fixed below
		int x = 100, y = 150, w = 200, h = 200;
		int x1 = 400, y1 = 100 , w1 = 300 , h1 = 300;
		// these quantities will need to be computed for each slice
		int startAngle = 0, degrees;
		int startAngle1 = 0, degrees1;
		
                
                try
           {
              Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
           } 
        
           catch (SQLException ex) 
           {
               Logger.getLogger(MangoPie1.class.getName()).log(Level.SEVERE, null, ex);
           }
         
              Connection conn = null;
              PreparedStatement ps1;
             
              
              int Quantities1[];
              Quantities1=new int[3];
              int Temp[];
              Temp=new int[3];
            
             
               try
               {
             
               conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","12345");
               PreparedStatement ps;
               ps = conn.prepareStatement("SELECT * FROM fruit_103");
               ps.executeQuery();
               ResultSet rs = ps.executeQuery();
               int numrow=0; 
               
                     while(rs.next())
                    {                                                 
                        for( int i=0;i<=2;i++)
                        {
                            Temp[i]=rs.getInt("F_Temp");  
                            Quantities1[i]=rs.getInt("F_Quantity");                             
                             rs.next();
                        }
                      
                    }
            
               
                  }
               
               catch (SQLException ex) 
               {
                        Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
               }
                               
                for(int i=0;i<=2;i++)                     
                {
                    System.out.println("Quantities:"+Quantities1[i]);
                    System.out.println("Quantities:"+Temp[i]);
                }
		
               Banana1 = Quantities1[0];
	       Banana2 = Quantities1[1];
	       Banana3 = Quantities1[2];
		
                Temp1 = Temp[0];
		Temp2 = Temp[1];
		Temp3 = Temp[2];
		
           
                
		
		
		// Computer percentages
		Total =Banana1 +Banana2 +Banana3;
		Total_Temp = Temp1 + Temp2 + Temp3;

          
		
		PercBanana1 = Banana1 * 100.0f / Total;
		PercBanana2 = Banana2 * 100.0f / Total;
		PercBanana3 = Banana3 * 100.0f / Total;
	
                PercTemp1 = Temp1 * 100.0f / Total_Temp;
		PercTemp2 = Temp2 * 100.0f / Total_Temp;
		PercTemp3 = Temp3 * 100.0f / Total_Temp;
                
                
                              
		// Print out results for checking

                Font f=new Font("TimesRoman",Font.BOLD,20);
                g.setFont(f);
		g.setColor(Color.black);
                g.drawString("Total-Bananas:"+Total,100,80);
		
		
                g.setColor(Color.red);
		g.drawString(""+Banana1,300,180);
                g.drawString("CAVENDISH:"+Banana1,150,450);
                
                g.setColor(Color.green);
                g.drawString(""+Banana2,80,200);
                g.drawString("MAHANANDI:"+Banana2,150,500);
	
                g.setColor(Color.blue);
                g.drawString(""+Banana3,200,380);
                g.drawString("ELAICHI:"+Banana3,150,550);
                
                g.setFont(f);
                g.setColor(Color.black);
                g.drawString("Temperature-Total:"+Total_Temp,500,80);
		
		g.setColor(Color.red);
                g.drawString(""+Temp1,700,180);
                g.drawString("CAVENDISH-Temp:"+Temp1,400,450);
                
		
                g.setColor(Color.green);
                g.drawString(""+Temp2,370,180);
                g.drawString("MAHANANDI-Temp:"+Temp2,400,500);
                
		g.setColor(Color.blue);
                g.drawString(""+Temp3,700,380);            
                g.drawString("ELAICHI-Temp:"+PercTemp3,400,550);			
	                       
		// Display the Pie Chart
		// Display the Pie for Banana1ences
		degrees = (int) (PercBanana1*360/100);
		g.setColor(Color.red);
		g.fillArc(x, y, w, h, startAngle, degrees);
                
                
                degrees1 = (int) (PercTemp1*360/100);
		g.setColor(Color.red);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
		
                
		
		// Pie for Banana2
		startAngle = degrees;
		degrees = (int) (PercBanana2*360/100);
                g.setColor(Color.green);
		g.fillArc(x, y, w, h, startAngle, degrees);
	
                
	
                
                startAngle1=degrees1;
                degrees1 = (int) (PercTemp2*360/100);
                g.setColor(Color.green);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
                    



// Pie for Banana3
		startAngle = startAngle + degrees;
		degrees = (int) (PercBanana3*360/100);
		g.setColor(Color.blue);
		g.fillArc(x, y, w, h, startAngle, degrees);
                
                startAngle1 = startAngle1 + degrees1;
                degrees1 = (int) (PercTemp3*360/100);
		g.setColor(Color.blue);
		g.fillArc(x1, y1, w1, h1, startAngle1, degrees1);
    
    
    
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Fruit_103");
        setAlwaysOnTop(true);
        setResizable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 884, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 555, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BananaPie1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
