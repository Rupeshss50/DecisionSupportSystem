import java.util.*;
public class KMeans
{
  public static void main(String args[])
  { 
    Scanner sc=new Scanner(System.in);
	float m1,m2;
	int count=0,count1=0,sum=0,sum1=0;      
	int k_means;
	int z=0,i=0;
    int z1=0;
	float avg1,avg2;
	System.out.println("Enter the no. of element in cluster:");
	k_means=sc.nextInt();
	int a[]=new int[k_means];
    int c1[]=new int[10];
	int c2[]=new int[10];
    
	System.out.println("Enter element in the cluster:");
	for(i=0;i<k_means;i++)
	{
      a[i]=sc.nextInt();
	}
	
     System.out.println("Enter the value of m1 & m2");	
     m1=sc.nextInt();
	 m2=sc.nextInt();
	 
		 for(i=0;i<k_means;i++)
		{
		 if(Math.abs(a[i]-m1)<Math.abs(a[i]-m2))
         {
		   c1[z]=a[i];
		   z++;
		 }
		 else
		 {
		  c2[z1]=a[i];
		  z1++;
		  }
		  }
		  
		  z=0;
		  z1=0;
		  System.out.print("Cluster 1:");
	      for(i=0;i<k_means;i++)
			 {
			    if(c1[i]!=0)
				{
				 System.out.println(c1[i]+"");
                }
              }
		  System.out.print("cluster 2:");
	       for( i=0;i<k_means;i++)
			 {
			    if(c2[i]!=0)
				{
				 System.out.println(c2[i]+"");
                }
              }
	
     	   
		   for( i=0;i<k_means;i++)
            {
              if(c1[i]!=0)
             {
               sum+=c1[i];
			   count++;
			  }
			  }
			   
		  avg1=(float)sum/count;
		  System.out.println("cluster1 Mean is"+avg1); 
		
		   for(i=0;i<k_means;i++)
            {
              if(c2[i]!=0)
             {
               sum1+=c2[i];
			   count1++;
			  }
			  }
		      avg2=(float)sum1/count1;
		      System.out.println("cluster2 Mean is:"+avg2);
		  }
		  }
		  