SQL> desc dss;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------

 USERID                                             VARCHAR2(10)
 PASSWORD                                           VARCHAR2(20)

SQL> select * from dss;

USERID     PASSWORD
---------- --------------------
100        admin100
101        staff101

SQL> desc admin100;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------

 F_ID                                               VARCHAR2(10)
 MESSAGE                                            VARCHAR2(500)

SQL> desc staff101;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------

 F_ID                                               VARCHAR2(10)
 MESSAGE                                            VARCHAR2(500)