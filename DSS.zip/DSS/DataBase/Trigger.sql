create or replace TRIGGER Admin_update after insert on Admin100
for each row
BEGIN
  insert into Staff101(F_id , message) values(:new.F_id,:new.message);
end;
/
