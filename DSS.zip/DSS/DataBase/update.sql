//***update the value from the given table ***//


// 1.update from fruit-100 mango

  update Fruit_101 set F_Temp=CASE F_ID
  when 1 then '32' 
  when 2 then '30' 
  when 3 then '38'
  End 
  where F_ID in (1, 2 ,3)
  /

  
// 2.update from fruit-101 Apple
 
  update Fruit_101 set F_Temp=CASE F_ID
  when 1 then '32' 
  when 2 then '30' 
  when 3 then '38'
  End 
  where F_ID in (1, 2 ,3)
  /
 
 // 3.update from fruit-102 Strowberries
 
  update Fruit_101 set F_Temp=CASE F_ID
  when 1 then '32' 
  when 2 then '30' 
  when 3 then '38'
  End 
  where F_ID in (1, 2 ,3)
  /

  // 4.update from fruit-103 banana 
 
  update Fruit_103 set F_Temp=CASE F_ID
  when 1 then '32' 
  when 2 then '30' 
  when 3 then '38'
  End 
  where F_ID in (1, 2 ,3)
  /

  // 5.update from fruit-104 BlackBerries
 
  update Fruit_104 set F_Temp=CASE F_ID
  when 1 then '32' 
  when 2 then '30' 
  when 3 then '38'
  End 
  where F_ID in (1, 2 ,3)
  /

  // 6.update from fruit-105 Grapes
 
  update Fruit_105 set F_Temp=CASE F_ID
  when 1 then '32' 
  when 2 then '30' 
  when 3 then '38'
  End 
  where F_ID in (1, 2 ,3)
  /

  // 7.update from fruit-106 Pears
 
  update Fruit_106 set F_Temp=CASE F_ID
  when 1 then '32' 
  when 2 then '30' 
  when 3 then '38'
  End 
  where F_ID in (1, 2 ,3)
  /

  