SQL> desc product;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------

 PRODUCT_ID                                NOT NULL VARCHAR2(20)
 PRODUCT_NAME                                       VARCHAR2(20)
 PRODUCT_PRIZE                                      NUMBER(20)
 PRODUCT_LOCATION                                   VARCHAR2(20)

SQL> select * from product;

PRODUCT_ID           PRODUCT_NAME         PRODUCT_PRIZE PRODUCT_LOCATION
-------------------- -------------------- ------------- --------------------
100                  mango                        20000 floor1_101
101                  apple                        15000 floor1_102
102                  Strawberries                 18000 floor1_103
103                  banana                       16000 floor2_101
104                  Blackberries                 21000 floor2_102
105                  Grapes                       18000 floor2_103
106                  Pears                        14000 floor2_104

7 rows selected.