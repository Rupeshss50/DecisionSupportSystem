             //****generating random Temprature value for table*******// 
		   
		   
     //Temperature for fruit_100-mango:

	 SQL> set serveroutput on
	 create procedure Temp1 
	 as
     begin
     for cur_rec in 1 ..3 loop
     dbms_output.put_line('Temp of fruit-100:mango ='|| dbms_random.value(30,40));
     end loop;
     end;
     /

	 //output
    SQL> exec temp1;
    Temperature of fruit-100:mango =38.027328904124366776556156576093039541
    Temperature of fruit-100:mango =37.6033119228895360986562332327998378377
    Temperature of fruit-100:mango =32.7369366337489198993181055883985772644
    PL/SQL procedure successfully completed.
	 
	 
	 
	 
	 
	 
	 
    //Temperature for fruit_101-Apple:
    SQL> set serveroutput on
	     create procedure Temp2 
	     as
         begin
         for cur_rec in 1 ..3 loop
         dbms_output.put_line('Temp of fruit-101:Apple ='|| dbms_random.value(30,50));
         end loop;
         end;
         /
	 	 
    SQL> exec Temp2
    Temperature of fruit-101:Apple =31.936672602020786370615183405325317371
    Temperature of fruit-101:Apple =33.9735344541625245674206191032045582146
    Temperature of fruit-101:Apple =44.609135137979552874385656335116735202
    PL/SQL procedure successfully completed.	 
	 

	 
//Temperature for fruit_102-Strawberries:
SQL> set serveroutput on
	 create procedure Temp3 
	 as
     begin
     for cur_rec in 1 ..3 loop
     dbms_output.put_line('Temp of fruit-102:Strawberries ='|| dbms_random.value(30,35));
     end loop;
     end;
     /
	 
    SQL> exec Temp3;
    Temperature of fruit-102:Strawberries =32.2995344589724278326826812233628253169
    Temperature of fruit-102:Strawberries =31.5389941852673496126108222808781039735
    Temperature of fruit-102:Strawberries =31.910902187298014672468037165135710166
    PL/SQL procedure successfully completed.
	 

//Temperature for fruit_103-banana:
SQL> set serveroutput on
	 create procedure Temp4 
	 as
     begin
     for cur_rec in 1 ..3 loop
     dbms_output.put_line('Temp of fruit-103:Banana ='|| dbms_random.value(30,50));
     end loop;
     end;
     /

	 SQL> exec temp4;
     Temperature of fruit-103:Banana =31.3129332818520527466244459635304230454
     Temperature of fruit-103:Banana =41.3289451523232234661345502121155846524
     Temperature of fruit-103:Banana =43.350278783539305673314201478117172846
	 
	 
	 
	 
	 
//Temperature for fruit_104-BlackBerries:
SQL> set serveroutput on
	 create procedure Temp5 
	 as
     begin
     for cur_rec in 1 ..3 loop
     dbms_output.put_line('Temp of fruit-104:BlackBerries ='|| dbms_random.value(30,35));
     end loop;
     end;
     /

 SQL> exec temp5;
     Temperature of fruit-104:BlackBerries =34.94095239404988163349339530855648076755
     Temperature of fruit-104:BlackBerries =32.0213290160706094163191541306713999745
     Temperature of fruit-104:BlackBerries =31.81533379153800350908316287719786566105 
	 //Temperature for fruit_105-Grapes:
	 
	 
	 
SQL> set serveroutput on
	 create procedure Temp6 
	 as
     begin
     for cur_rec in 1 ..3 loop
     dbms_output.put_line('Temp of fruit-105:Grapes ='|| dbms_random.value(30,40));
     end loop;
     end;
     /

	 SQL> exec temp6;
     Temperature of fruit-105:Grapes =32.6553279082908048448150681201206529778
     Temperature of fruit-105:Grapes =35.0480222194675064295113617819449897445
     Temperature of fruit-105:Grapes =35.0976787959464457397789220158595353694
     PL/SQL procedure successfully completed.
	 
	 	 
//Temperature for fruit_106-Pears:
SQL> set serveroutput on
	 create procedure Temp7 
	 as
     begin
     for cur_rec in 1 ..3 loop
     dbms_output.put_line('Temp of fruit-106:Pears ='|| dbms_random.value(30,50));
     end loop;
     end;
     /	 
	 
	 Temperature of fruit-106:Pears =44.842373413673727003496241396841915518
     Temperature of fruit-106:Pears =31.5477201743424678223008589919212753744
     Temperature of fruit-106:Pears =35.8263838079993874937393495504590498154
	 PL/SQL procedure successfully completed.