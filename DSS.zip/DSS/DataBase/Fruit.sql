 //*** fruit table ***//
 Fruit_100:

 SQL> create table Fruit_100(f_id number(20) primary key , f_name varchar2(20) ,
f_season varchar2(20) , f_Temp number(20) , f_Quantity number(10) ,Order_date da
te , expiry_date date , product_id varchar2(10) references   product );

Table created. 

SQL> desc fruit_100;
 Name                                      Null?    Type
 ----------------------------------------- -------- --------------------------

 F_ID                                      NOT NULL NUMBER(20)
 F_NAME                                             VARCHAR2(20)
 F_SEASON                                           VARCHAR2(20)
 F_TEMP                                             NUMBER(20)
 F_QUANTITY                                         NUMBER(10)
 ORDER_DATE                                         DATE
 EXPIRY_DATE                                        DATE
 PRODUCT_ID                                         VARCHAR2(10)


SQL>insert into fruit_100 values('1','Alphonso','april-may','35','40','10-FEB-2015','15-APR-2015','100'); 
SQL>insert into fruit_100 values('2','Totapuri','april-june','40','50','20-FEB-2015','20-APR-2015','100');
SQL>insert into fruit_100 values('3','Dasheri','june-july','38','55','25-FEB-2015','30-APR-2015','100');

 
 
 table
 
SQL> select * from fruit_100;

      F_ID F_NAME               F_SEASON                 F_TEMP F_QUANTITY
---------- -------------------- -------------------- ---------- ----------
ORDER_DAT EXPIRY_DA PRODUCT_ID
--------- --------- ----------
         1 Alphonso             april-may                    35         40
10-FEB-15 15-APR-15 100

         2 Totapuri             april-june                   40         50
20-FEB-15 20-APR-15 100

         3 Dasheri              june-july                    38         55
25-FEB-15 30-APR-15 100







 
 2.Fruit Fruit_101:
 
 SQL> create table Fruit_101(f_id number(20) primary key , f_name varchar2(20) ,f_season varchar2(20) , f_Temp number(20) , f_Quantity number(10) ,Order_date date , expiry_date date , product_id varchar2(10) references   product );

SQL>insert into fruit_101 values('1','Simla','Jan-may','30','40','10-FEB-2015','15-APR-2015','101'); 
SQL>insert into fruit_101 values('2','Dewgan','april-june','40','50','20-FEB-2015','20-APR-2015','101');
SQL>insert into fruit_101 values('3','Fuzi','jun-Aug','35','55','25-FEB-2015','30-APR-2015','101');
 
SQL> select * from fruit_101;

      F_ID F_NAME               F_SEASON                 F_TEMP F_QUANTITY
---------- -------------------- -------------------- ---------- ----------
ORDER_DAT EXPIRY_DA PRODUCT_ID
--------- --------- ----------
         1 Simla                Jan-may                      30         40
10-FEB-15 15-APR-15 101

         2 Dewgan               april-june                   40         50
20-FEB-15 20-APR-15 101

         3 Fuzi                 jun-Aug                      35         55
25-FEB-15 30-APR-15 101

 
 
3.Strawberries
SQL>create table Fruit_102(f_id number(20) primary key , f_name varchar2(20) ,f_season varchar2(20) , f_Temp number(20) , f_Quantity number(10) ,Order_date date , expiry_date date , product_id varchar2(10) references   product );


SQL>insert into fruit_102 values('1','EVERBEARING','feb-may','32','30','10-FEB-2015','15-APR-2015','102'); 
SQL>insert into fruit_102 values('2','Day-Neutral','april-may','30','40','20-FEB-2015','20-APR-2015','102');
SQL>insert into fruit_102 values('3','June-Bearing','jun-Aug','30','55','25-FEB-2015','30-APR-2015','102');


 SQL> select * from fruit_102;

      F_ID F_NAME               F_SEASON                 F_TEMP F_QUANTITY
---------- -------------------- -------------------- ---------- ----------
ORDER_DAT EXPIRY_DA PRODUCT_ID
--------- --------- ----------
         1 EVERBEARING          feb-may                      32         30
10-FEB-15 15-APR-15 102

         2 Day-Neutral          april-may                    30         40
20-FEB-15 20-APR-15 102

         3 June-Bearing         jun-Aug                      30         55
25-FEB-15 30-APR-15 102
 
 
 
 4.BANANA
 
SQL>create table Fruit_103(f_id number(20) primary key , f_name varchar2(20) ,f_season varchar2(20) , f_Temp number(20) , f_Quantity number(10) ,Order_date date , expiry_date date , product_id varchar2(10) references   product );

SQL>insert into fruit_103 values('1','Cavendish','jan-aug','30','50','10-FEB-2015','15-may-2015','103'); 
SQL>insert into fruit_103 values('2','Mahanandi','feb-may','35','40','20-FEB-2015','20-APR-2015','103');
SQL>insert into fruit_103 values('3','Elaichi','may-sept','40','55','25-FEB-2015','30-APR-2015','103');
 
 
 SQL> select * from fruit_103;

      F_ID F_NAME               F_SEASON                 F_TEMP F_QUANTITY
---------- -------------------- -------------------- ---------- ----------
ORDER_DAT EXPIRY_DA PRODUCT_ID
--------- --------- ----------
         1 Cavendish            jan-aug                      30         50
10-FEB-15 15-MAY-15 103

         2 Mahanandi            feb-may                      35         40
20-FEB-15 20-APR-15 103

         3 Elaichi              may-sept                     40         55
25-FEB-15 30-APR-15 103


5.BlackBerries1
SQL>create table Fruit_104(f_id number(20) primary key , f_name varchar2(20) ,f_season varchar2(20) , f_Temp number(20) , f_Quantity number(10) ,Order_date date , expiry_date date , product_id varchar2(10) references   product );

SQL>insert into fruit_104 values('1','BlackBerries','jan-aug','30','30','10-FEB-2015','15-may-2015','104'); 
SQL>insert into fruit_104 values('2','BlueBerries','feb-may','35','45','20-FEB-2015','20-may-2015','104');
SQL>insert into fruit_104 values('3','RaasBerries','may-sept','40','50','25-FEB-2015','30-may-2015','104');

SQL> select * from fruit_104;

      F_ID F_NAME               F_SEASON                 F_TEMP F_QUANTITY
---------- -------------------- -------------------- ---------- ----------
ORDER_DAT EXPIRY_DA PRODUCT_ID
--------- --------- ----------
         1 BlackBerries         jan-aug                      30         30
10-FEB-15 15-MAY-15 104

         2 BlueBerries          feb-may                      35         45
20-FEB-15 20-MAY-15 104

         3 RaasBerries          may-sept                     40         50
25-FEB-15 30-MAY-15 104


6.Grapes
SQL>create table Fruit_105(f_id number(20) primary key , f_name varchar2(20) ,f_season varchar2(20) , f_Temp number(20) , f_Quantity number(10) ,Order_date date , expiry_date date , product_id varchar2(10) references   product );

SQL>insert into fruit_105 values('1','Champagne','jan-aug','30','30','10-FEB-2015','15-may-2015','105'); 
SQL>insert into fruit_105 values('2','Concard','feb-may','32','35','20-FEB-2015','20-APR-2015','105');
SQL>insert into fruit_105 values('3','Cotton-candy','jan-sept','34','40','25-FEB-2015','30-APR-2015','105');


SQL> select * from fruit_105;

      F_ID F_NAME               F_SEASON                 F_TEMP F_QUANTITY
---------- -------------------- -------------------- ---------- ----------
ORDER_DAT EXPIRY_DA PRODUCT_ID
--------- --------- ----------
         1 Champagne            jan-aug                      30         30
10-FEB-15 15-MAY-15 105

         2 Concard              feb-may                      32         35
20-FEB-15 20-APR-15 105

         3 Cotton-candy         jan-sept                     34         40
25-FEB-15 30-APR-15 105


7.pears



SQL>create table Fruit_106(f_id number(20) primary key , f_name varchar2(20) ,f_season varchar2(20) , f_Temp number(20) , f_Quantity number(10) ,Order_date date , expiry_date date , product_id varchar2(10) references   product );

SQL>insert into fruit_106 values('1','ANJOU','jan-aug','40','30','10-FEB-2015','15-may-2015','106'); 
SQL>insert into fruit_106 values('2','BARTLETT','feb-may','50','30','20-FEB-2015','20-APR-2015','106');
SQL>insert into fruit_106 values('3','BOSC','jan-sept','55','30','25-FEB-2015','30-APR-2015','106');


SQL> select * from fruit_106;

      F_ID F_NAME               F_SEASON                 F_TEMP F_QUANTITY
---------- -------------------- -------------------- ---------- ----------
ORDER_DAT EXPIRY_DA PRODUCT_ID
--------- --------- ----------
         1 ANJOU                jan-aug                      40         30
10-FEB-15 15-MAY-15 106

         2 BARTLETT             feb-may                      50         30
20-FEB-15 20-APR-15 106

         3 BOSC                 jan-sept                     55         30
25-FEB-15 30-APR-15 106

